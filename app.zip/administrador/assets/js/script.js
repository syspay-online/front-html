// Redirecionar para o dashboard após login
document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('login-form');
    const userList = document.getElementById('user-list');
    const searchInput = document.getElementById('search-input');
    const searchButton = document.getElementById('search-button');
    const loginError = document.getElementById('login-error');

    // Função de login
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;

            try {
                const response = await fetch('http://localhost:3000/users/login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email, senha: password }),
                });

                const data = await response.json();

                if (response.ok) {
                    // Redireciona para o dashboard após login bem-sucedido
                    window.location.href = './dashboard.html';
                } else {
                    loginError.textContent = data.message || 'Erro ao fazer login';
                }
            } catch (error) {
                loginError.textContent = 'Erro ao conectar ao servidor';
                console.error(error);
            }
        });
    }

    // Função para listar todos os usuários
    async function listUsers(filter = '') {
        try {
            const response = await fetch(`http://localhost:3000/users`);
            const data = await response.json();

            if (Array.isArray(data)) {
                userList.innerHTML = '';
                data
                    .filter(user => {
                        if (!filter) return true;
                        return user.nome.toLowerCase().includes(filter.toLowerCase()) || user.id.toString() === filter;
                    })
                    .forEach(user => {
                        const row = document.createElement('tr');
                        row.innerHTML = `
                            <td>${user.id}</td>
                            <td>${user.nome}</td>
                            <td>${user.cpf}</td>
                            <td>${user.cep}</td>
                            <td>${user.endereco}</td>
                            <td>${user.celular}</td>
                            <td>${user.email}</td>
                        `;
                        userList.appendChild(row);
                    });
            } else {
                userList.innerHTML = '<tr><td colspan="7">Erro ao carregar usuários</td></tr>';
            }
        } catch (error) {
            userList.innerHTML = '<tr><td colspan="7">Erro ao conectar ao servidor</td></tr>';
            console.error(error);
        }
    }

    // Chamar a função para listar usuários ao carregar o dashboard
    if (userList) {
        listUsers();

        // Buscar usuário por nome ou ID
        searchButton.addEventListener('click', () => {
            const filter = searchInput.value;
            listUsers(filter);
        });
    }
});
