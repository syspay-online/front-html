// Defina a URL da API fora das funções
const API_URL = 'http://localhost:3000/users';

// Exibir submenus ao clicar
function toggleSubmenu(submenuId) {
  const submenu = document.getElementById(submenuId);
  submenu.style.display = submenu.style.display === 'block' ? 'none' : 'block';
}

// Saudação ao usuário
window.onload = async () => {
  const username = localStorage.getItem('username') || 'Administrador';
  document.getElementById('username').innerText = username;

  // Atualizar total de usuários e listar todos os cadastrados
  try {
    const response = await fetch(API_URL);
    const users = await response.json();

    // Total de usuários
    document.getElementById('total-users').innerText = users.length;

    // Listar todos os usuários
    const tbody = document.getElementById('all-users-table');
    let currentIndex = 0;
    const usersPerPage = 10;

    // Função para exibir os usuários (10 de cada vez)
    function displayUsers() {
      const usersToDisplay = users.slice(currentIndex, currentIndex + usersPerPage);
      usersToDisplay.forEach(user => {
        const row = `
          <tr>
            <td>${user.id}</td>
            <td>${user.nome}</td>
            <td>${user.cpf}</td>
            <td>${user.email}</td>
            <td>
              <button onclick="editUser(${user.id})">Editar</button>
              <button onclick="deleteUser(${user.id})">Excluir</button>
            </td>
          </tr>
        `;
        tbody.innerHTML += row;
      });

      // Atualizar o índice para carregar os próximos usuários
      currentIndex += usersPerPage;
    }

    // Função para carregar mais usuários ao rolar
    const tableContainer = document.querySelector('.users-table-container');
    tableContainer.addEventListener('scroll', () => {
      if (tableContainer.scrollTop + tableContainer.clientHeight >= tableContainer.scrollHeight) {
        // Carregar mais usuários, se existirem
        if (currentIndex < users.length) {
          displayUsers();
        }
      }
    });

    // Carregar os usuários inicialmente
    displayUsers();
  } catch (error) {
    console.error('Erro ao buscar usuários:', error);
  }
};

// Buscar usuários
document.getElementById('search-button').onclick = async () => {
  const searchInput = document.getElementById('search-input').value.trim();
  if (!searchInput) return alert('Digite um ID, Nome ou CPF!');

  try {
    const response = await fetch(API_URL);
    const users = await response.json();
    const filtered = users.filter(user => 
      user.id.toString() === searchInput ||
      user.nome.toLowerCase().includes(searchInput.toLowerCase()) ||
      user.cpf === searchInput
    );

    const tbody = document.getElementById('user-table').querySelector('tbody');
    tbody.innerHTML = filtered.length 
      ? filtered.map(user => `
          <tr>
            <td>${user.id}</td>
            <td>${user.nome}</td>
            <td>${user.cpf}</td>
            <td>${user.email}</td>
            <td>
              <button onclick="editUser(${user.id})">Editar</button>
              <button onclick="deleteUser(${user.id})">Excluir</button>
            </td>
          </tr>
        `).join('')
      : '<tr><td colspan="5">Nenhum usuário encontrado</td></tr>';
  } catch (error) {
    console.error('Erro ao buscar usuários:', error);
  }
};

// Editar e Excluir (ações básicas)
function editUser(id) {
  alert(`Editar usuário com ID: ${id}`);
}

async function deleteUser(id) {
  if (confirm(`Deseja excluir o usuário com ID: ${id}?`)) {
    try {
      await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
      alert('Usuário excluído com sucesso!');
      window.location.reload();
    } catch (error) {
      console.error('Erro ao excluir usuário:', error);
    }
  }
}

// Verifica se o usuário está logado e se o login expirou
function checkAuthentication() {
  const username = localStorage.getItem('username');
  const loginExpire = localStorage.getItem('loginExpire');

  if (!username || !loginExpire || Date.now() > parseInt(loginExpire, 10)) {
    alert('Sessão expirada! Faça login novamente.');
    localStorage.clear();
    window.location.href = './login.html';
    return false;
  }
}
