const API_URL = 'http://localhost:3000/users/login';

document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('login-form');
    const loginError = document.getElementById('login-error');

    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value.trim();

        try {
            const response = await fetch(API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, senha: password }),
            });

            if (response.ok) {
                const data = await response.json();

                // Salvar token e nome do usuário no localStorage
                localStorage.setItem('authToken', data.token);
                localStorage.setItem('username', data.nome);
                localStorage.setItem('loginExpire', Date.now() + 5 * 60 * 1000); // 5 minutos

                // Redirecionar para o dashboard
                window.location.href = './dashboard.html';
            } else {
                const errorData = await response.json();
                loginError.textContent = errorData.message || 'Erro ao fazer login';
            }
        } catch (error) {
            loginError.textContent = 'Erro ao conectar ao servidor';
            console.error(error);
        }
    });
});
