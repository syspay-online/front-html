async function login() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    
    // Supondo que sua API de backend tem um endpoint para login
    const response = await fetch('http://localhost:3000/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ email, password })
    });
  
    const result = await response.json();
  
    if (response.ok) {
      localStorage.setItem('username', result.username);  // Salva no localStorage
      window.location.href = './home.html';  // Redireciona para a home do usuário
    } else {
      alert('Falha no login. Verifique suas credenciais.');
    }
}
  