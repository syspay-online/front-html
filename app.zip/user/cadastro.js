document.getElementById('cadastro-form').addEventListener('submit', async function (event) {
    event.preventDefault();
  
    const formData = new FormData(this);
  
    const userData = {
      nome: formData.get('nome'),
      cpf: formData.get('cpf'),
      cep: formData.get('cep'),
      endereco: formData.get('endereco'),
      celular: formData.get('celular'),
      email: formData.get('email'),
      senha: formData.get('senha'),
    };
  
    try {
      const response = await fetch('http://localhost:3000/users/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(userData),
      });
  
      if (response.ok) {
        alert('Usuário cadastrado com sucesso!');
        window.location.href = './login.html'; // Redireciona para login após cadastro
      } else {
        const errorData = await response.json();
        alert('Erro ao cadastrar usuário: ' + errorData.message);
      }
    } catch (error) {
      console.error('Erro na requisição:', error);
      alert('Erro ao conectar com o servidor.');
    }
});
  